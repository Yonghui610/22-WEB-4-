// 向外部导出内容
export let a = 10
export const b = "孙悟空"
export const c = { name: "猪八戒" }