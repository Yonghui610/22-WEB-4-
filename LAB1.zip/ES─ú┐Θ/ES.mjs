// 动态导入 m1.mjs

import { a, b, c } from "./m1.mjs"
console.log(c)
c.name = "沙和尚"
console.log(c)

