module.exports = {
    a: "哈哈",
    b: [1, 3, 5, 7],
    c: () => {
        console.log(111)
    }
}