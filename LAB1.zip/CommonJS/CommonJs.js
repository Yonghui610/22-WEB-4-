const m1 = require("./m1")
m1.c()
console.log(m1.a)