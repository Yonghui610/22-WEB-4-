const express = require("express");
const router = express.Router();
const movieController = require("../controllers/movieController");

// 登录    
router.post("/movies/login", movieController.login);

// // 登出路由
router.get("/movies/logout", movieController.logout);

// 注册普通新用户
// router.post("/studentRegister", studentController.registerUser);

// 增加验证是否登录
// router.use(movieController.checkLogin);

// 获取所有用户
router.get("/movies", movieController.getMovies);
router.get("/movies/all", movieController.getAllMovie);

//首页展示
router.get("/movies/show", movieController.showAllMovies);


// 添加新用户
router.post("/movies", movieController.createMovie);


// 根据 ID 获取单个用户
router.get("/movies/:id", movieController.getMovieById);
router.get("/moviedetail/:id", movieController.movieDetail);

// 删除用户
router.delete("/movies/:id", movieController.deleteMovie);
// 用get方法模拟delete
router.get("/movies/delete/:id", movieController.deleteMovie);

// 更新用户
router.put("/movies", movieController.updateMovie);
// 用post方法模拟put
router.post("/movies/update", movieController.updateMovie);
router.post("/movies/updateFilmId", movieController.updateFilmId);
router.post("/movies/updatePopularity", movieController.updatePopularity);

module.exports = router;

