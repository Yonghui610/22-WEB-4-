const express = require("express");
const router = express.Router();
const studentController = require("../controllers/studentController");

// 登录
router.post("/students/login", studentController.login);
router.get("/students/logout", studentController.logout);

// 注册
router.post("/students/register", studentController.regist);

// 获取所有学生
router.get("/students", studentController.getStudents);

// 根据 ID 获取学生信息
router.get("/students/:id", studentController.getUserById);

// 修改学生信息
router.post("/students/update", studentController.updateUser);

// 添加学生
router.post("/students", studentController.createUser);

// 删除学生
router.get("/students/delete/:id", studentController.deleteUser);

// 修改密码
router.get("/students/mofpwd/:id", studentController.renderChangePasswordPage);
router.post("/students/changePassword", studentController.changePassword);

module.exports = router;
