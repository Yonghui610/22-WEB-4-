const movieService = require("../services/movieService");
const userService = require("../services/userService");


exports.login = async (req, res, next) => {
    try {
        const { name, pwd } = req.body;
        const user = await userService.getUserByName(name);
        if (!user) {
            return res.json({
                code: 404,
                success: false,
                message: "账号不存在",
            });
        }
        if (user.pwd !== pwd) {
            return res.json({
                code: 401,
                success: false,
                message: "密码错误",
            });
        }

        if (user.name === "admin") {
            res.redirect("/movs/movies");
        } else {
            res.redirect(`/moviesCenter.html`);
        }
    } catch (err) {
        next(err);
    }
};



exports.getMovies = async (req, res, next) => {
    try {
        const movies = await movieService.getMovies();
        res.render("movies", { movs: movies });
    } catch (err) {
        next(err);
    }
};

exports.getAllMovie = async (req, res, next) => {
    try {
        const movies = await movieService.getMovies();
        res.render("Allmovie", { movs: movies });

    } catch (err) {
        next(err);
    }
};

// 没有变化
exports.getMovieById = async (req, res, next) => {
    try {
        const movie = await movieService.getMovieById(req.params.id);
        if (!movie) {
            return null;
        } else {
            res.render("movieModify", { movie: movie });
        }
    } catch (err) {
        next(err);
    }
};

exports.logout = async (req, res, next) => {
    res.redirect("/");
};


exports.createMovie = async (req, res, next) => {
    try {
        const newMovie = req.body;
        console.log(newMovie);
        const createMovieResult = await movieService.getMovieByName(newMovie.name);
        if (createMovieResult) {
            res.redirect("/movs/movies");
        } else {
            newMovie.posterUrl = "http://localhost:5000/images/peoples/员工.png";
            await movieService.createMovie(newMovie);

            res.redirect("/movs/movies/all");
        }
    } catch (err) {
        next(err);
    }
};

exports.deleteMovie = async (req, res, next) => {
    try {
        const movieId = req.params.id;
        await movieService.deleteMovie(movieId);
        res.redirect("/movs/movies/all");
    } catch (err) {
        next(err);
    }
};


exports.updateMovie = async (req, res, next) => {
    try {
        const updatedMovie = req.body;
        const updateMovieResult = await movieService.getMovieById(updatedMovie.filmId);
        updatedMovie.posterUrl = updateMovieResult.posterUrl;
        await movieService.updateMovie(updatedMovie);

        res.redirect("/movs/movies/all");
    } catch (err) {
        next(err);
    }
};

exports.showAllMovies = async (req, res, next) => {
    try {
        const movies = await movieService.getMovies(); // 假设这是获取所有电影的数据库查询
        res.json({ success: true, movies }); // 返回电影数据，格式化成 JSON
    } catch (err) {
        next(err);
    }
};

exports.movieDetail = async (req, res, next) => {
    try {
        const filmId = req.params.id; // 从路径参数获取 filmId
        // console.log("Requested filmId:", filmId);

        const movie = await movieService.getMovieById(filmId); // 基于 filmId 查询
        // console.log("Queried Movie:", movie);

        if (!movie) {
            return res.json({ success: false, message: "电影未找到" });
        } else {
            res.json({
                success: true,
                data: { film: movie } // 返回前端预期的数据结构
            });
        }
    } catch (err) {
        console.error("Error fetching movie details:", err);
        next(err);
    }
};


// 新增：更新电影人气值
exports.updatePopularity = async (req, res, next) => {
    try {
        const { filmId, change } = req.body; // 确保使用req.body获取参数

        if (!filmId || isNaN(change)) {
            return res.status(400).json({
                success: false,
                message: "无效的参数"
            });
        }

        const updatedPopularity = await movieService.updatePopularity(filmId, parseInt(change));

        res.json({
            success: true,
            updatedPopularity
        });
    } catch (err) {
        console.error("更新电影人气值失败:", err);
        next(err);
    }
};

exports.updateFilmId = async (req, res, next) => {
    try {
        const { filmId, change } = req.body;

        if (!filmId || isNaN(change)) {
            return res.status(400).json({
                success: false,
                message: "无效的参数"
            });
        }

        const newFilmId = await movieService.updateFilmId(filmId, parseInt(change));
        res.status(200).json({
            success: true,
            newFilmId
        });
    } catch (err) {
        console.error("Error in updateFilmId:", err.message);

        // 返回更详细的错误信息给前端
        res.status(500).json({
            success: false,
            message: err.message || "未知错误"
        });
    }
};
