const userService = require("../services/userService");

// 登录
exports.login = async (req, res, next) => {
    try {
        const { name, pwd } = req.body;
        const user = await userService.getUserByName(name);

        if (!user) {
            return res.json({
                code: 404,
                success: false,
                message: "账号不存在，请重新输入！",
            });
        }

        if (user.pwd !== pwd) {
            return res.json({
                code: 401,
                success: false,
                message: "密码错误，请重新输入！",
            });
        }

        // 登录成功，设置 session
        req.session.loginUser = user.name;
        req.session.save(() => {
            res.json({
                code: 200,
                success: true,
                message: "登录成功",
                redirectUrl: user.name === "admin" ? "/stus/students" : `/stus/students/${user.id}`,
            });
        });
    } catch (err) {
        next(err);
    }
};

// 登出
exports.logout = (req, res, next) => {
    try {
        // 清除 session
        req.session.destroy(err => {
            res.redirect("/");
            if (err) {
                console.error("Error destroying session:", err)
            }
        });
    } catch (err) {
        next(err);
    }
};

// 获取所有学生信息，渲染管理员页面
exports.getStudents = async (req, res, next) => {
    try {
        const users = await userService.getUsers();
        res.render("students", {
            stus: users,
            loginUserName: req.session.loginUser,
        });
    } catch (err) {
        next(err);
    }
};
// 添加用户
exports.createUser = async (req, res, next) => {
    try {
        const newUser = req.body;

        // 检查字段是否完整，提供默认值
        newUser.age = newUser.age ? parseInt(newUser.age) : 0;
        newUser.gender = newUser.gender || "未填写";
        newUser.address = newUser.address || "未填写";
        newUser.Tel = newUser.Tel || "未填写";
        newUser.imgUrl = "http://localhost:5000/images/peoples/员工.png";

        // 检查用户名是否已存在
        const existingUser = await userService.getUserByName(newUser.name);
        if (existingUser) {
            const users = await userService.getUsers();
            return res.render("students", {
                stus: users,
                loginUserName: req.session.loginUser,
                success: null,
                error: "用户名已存在，请重新输入！",
            });
        }

        // 添加新用户
        await userService.createUser(newUser);

        // 获取更新后的学生列表
        const users = await userService.getUsers();
        res.render("students", {
            stus: users,
            loginUserName: req.session.loginUser,
            success: "新用户添加成功！",
            error: null,
        });
    } catch (err) {
        console.error("Error creating user:", err);
        res.render("students", {
            stus: await userService.getUsers(),
            loginUserName: req.session.loginUser,
            success: null,
            error: "添加新用户失败，请重试！",
        });
    }
};

// 根据 ID 获取单个学生信息，渲染修改页面
exports.getUserById = async (req, res, next) => {
    try {
        const user = await userService.getUserById(req.params.id);
        if (!user) {
            // 如果学生不存在，重定向回学生列表页面
            return res.redirect("/stus/students");
        }
        res.render("student", { student: user });
    } catch (err) {
        next(err);
    }
};

// 修改用户信息
exports.updateUser = async (req, res, next) => {
    try {
        const updatedUser = req.body;

        // 检查并提供默认值，避免字段为 null
        updatedUser.age = updatedUser.age ? parseInt(updatedUser.age) : 0;
        updatedUser.gender = updatedUser.gender || "未填写";
        updatedUser.address = updatedUser.address || "未填写";
        updatedUser.Tel = updatedUser.Tel || "未填写";

        // 获取原用户数据
        const user = await userService.getUserById(updatedUser.id);
        if (!user) {
            // 如果用户不存在，重定向回学生列表页面
            return res.redirect("/stus/students");
        }

        // 保留头像 URL
        updatedUser.imgUrl = user.imgUrl;

        // 更新用户数据
        await userService.updateUser(updatedUser);

        // 获取更新后的学生列表
        const users = await userService.getUsers();
        res.render("students", {
            stus: users,
            loginUserName: req.session.loginUser,
        });
    } catch (err) {
        console.error(`Error updating user with ID ${req.body.id}:`, err);
        next(err);
    }
};

// 注册新用户
exports.regist = async (req, res, next) => {
    try {
        const newUser = req.body;
        const user = await userService.getUserByName(newUser.name);
        if (user) {
            // 如果用户名已存在，返回注册页面
            return res.redirect("/userRegister.html");
        }
        newUser.imgUrl = "http://localhost:5000/images/peoples/员工.png";
        await userService.createUser(newUser);
        res.redirect("/usersCenter.html");
    } catch (err) {
        next(err);
    }
};

// 修改密码页面渲染
exports.renderChangePasswordPage = (req, res, next) => {
    const userId = req.params.id;
    res.render("changePwd", { userId });
};

// 修改密码
exports.changePassword = async (req, res, next) => {
    try {
        const { userId, newPwd, oldPwd, confirmNewPwd } = req.body;

        if (newPwd !== confirmNewPwd) {
            return res.render("changePwd", {
                userId,
                error: "新密码和确认密码不一致，请重新输入！",
            });
        }

        const user = await userService.getUserById(userId);
        if (!user || user.pwd !== oldPwd) {
            return res.render("changePwd", {
                userId,
                error: "旧密码错误，请重新输入！",
            });
        }

        await userService.changePassword(userId, newPwd);
        res.redirect("/stus/students");
    } catch (err) {
        next(err);
    }
};

// 删除用户
exports.deleteUser = async (req, res, next) => {
    try {
        const userId = req.params.id;
        await userService.deleteUser(userId);

        const users = await userService.getUsers();
        res.render("students", {
            stus: users,
            loginUserName: req.session.loginUser,
        });
    } catch (err) {
        next(err);
    }
};

