const { createPool } = require("mysql2/promise");
const dbConfig = require("../config/dbConfig");
const pool = createPool(dbConfig);

class Movie {
    constructor(id, filmId, name, description, posterUrl, popularity) {
        this.id = id;
        this.filmId = filmId
        this.name = name;
        this.description = description;
        this.posterUrl = posterUrl;
        this.popularity = popularity;
    }

    static async getMovies() {
        try {
            const [rows] = await pool.query("SELECT * FROM movie");
            return rows.map(
                (row) =>
                    new Movie(
                        row.id,
                        row.filmId,
                        row.name,
                        row.description,
                        row.posterUrl,
                        row.popularity
                    )
            );
        } catch (err) {
            console.error("Error fetching movies:", err);
            throw err;
        }
    }

    static async getMovieByName(name) {
        try {
            const [rows] = await pool.query("select * from movie where name = ?", [
                name,
            ]);
            if (rows.length === 0) {
                return null;
            }
            return new Movie(
                rows[0].id,
                rows[0].filmId,
                rows[0].name,
                rows[0].description,
                rows[0].posterUrl,
                rows[0].popularity
            );
        } catch (err) {
            console.error(`Error fetching movie with Name ${name}:`, err);
            throw err;
        }
    }

    static async getMovieById(filmId) {
        try {
            const [rows] = await pool.query("SELECT * FROM movie WHERE filmId = ?", [filmId]);
            if (rows.length === 0) {
                return null;
            }
            return new Movie(
                rows[0].id,
                rows[0].filmId,
                rows[0].name,
                rows[0].description,
                rows[0].posterUrl,
                rows[0].popularity
            );
        } catch (err) {
            console.error(`Error fetching movie with filmId ${filmId}:`, err);
            throw err;
        }
    }


    static async createMovie(filmId, name, description, posterUrl, popularity) {
        try {
            const [result] = await pool.query(
                "INSERT INTO movie (filmId, name, description, posterUrl, popularity) VALUES (?, ?, ?, ?, ?)",
                [filmId, name, description, posterUrl, popularity]
            );
            return result.insertId;
            // 返回新插入记录的 ID
        } catch (err) {
            console.error("Error creating movie:", err);
            throw err;
        }
    }

    static async updateMovie(id, filmId, name, description, posterUrl, popularity) {
        try {
            await pool.query(
                "UPDATE movie SET filmId = ?,  name = ?, description = ?, posterUrl = ? , popularity = ? WHERE id = ?",
                [filmId, name, description, posterUrl, popularity, id]
            );
        } catch (err) {
            console.error(`Error updating movie with ID ${id}:`, err);
            throw err;
        }
    }

    static async deleteMovie(id) {
        try {
            await pool.query("DELETE FROM movie WHERE id = ?", [id]);
        } catch (err) {
            console.error(`Error deleting movie with ID ${id}:`, err);
            throw err;
        }
    }

    static async updatePopularity(filmId, change) {
        try {
            // 使用 SQL 的 UPDATE 和 SET 语句更新人气值
            const [result] = await pool.query(
                "UPDATE movie SET popularity = popularity + ? WHERE filmId = ?",
                [change, filmId]
            );

            // 判断更新结果
            if (result.affectedRows === 0) {
                throw new Error("电影未找到或更新失败");
            }

            // 返回更新后的人气值
            const [rows] = await pool.query("SELECT popularity FROM movie WHERE filmId = ?", [filmId]);
            return rows[0].popularity;
        } catch (err) {
            console.error(`Error updating popularity for movie with filmId ${filmId}:`, err);
            throw err;
        }
    }

    static async updateFilmId(filmId, change) {
        try {
            // 确保 filmId 是字符串
            const currentFilmId = String(filmId);
            const newFilmId = String(parseInt(currentFilmId) + change);

            // 检查新的 filmId 是否已存在，避免冲突
            const [existingRows] = await pool.query("SELECT * FROM movie WHERE filmId = ?", [newFilmId]);
            if (existingRows.length > 0) {
                throw new Error(`电影ID ${newFilmId} 已存在，无法更新。`);
            }

            // 更新 filmId
            const [result] = await pool.query(
                "UPDATE movie SET filmId = ? WHERE filmId = ?",
                [newFilmId, currentFilmId]
            );

            if (result.affectedRows === 0) {
                throw new Error(`电影ID ${currentFilmId} 未找到或更新失败`);
            }

            return newFilmId;
        } catch (err) {
            console.error(`Error in updateFilmId: ${err.message}`);
            throw err;
        }
    }


}

module.exports = Movie;
