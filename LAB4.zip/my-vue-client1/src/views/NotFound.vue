
<template>
    <div>
        <!-- 404 not found -->
        <img src="/404.png" alt="" width="300">
    </div>
</template>
