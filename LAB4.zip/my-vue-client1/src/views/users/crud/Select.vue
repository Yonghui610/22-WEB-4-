<template>
  <div class="container">
    <!-- 无数据，不显示表头 -->
    <template v-if="isShow">
      <table>
        <caption>学生列表</caption>
        <thead>
          <tr>
            <th>学号</th>
            <th>姓名</th>
            <th>密码</th>
            <th>年龄</th>
            <th>性别</th>
            <th>地址</th>
            <th>头像</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="item in datalist" :key="item.id">
            <td>{{ item.id }}</td>
            <td>{{ item.name }}</td>
            <td>{{ item.pwd }}</td>
            <td>{{ item.age }}</td>
            <td>{{ item.gender }}</td>
            <td>{{ item.address }}</td>
            <td><img :src="item.imgUrl" alt="头像" /></td>
          </tr>
        </tbody>
      </table>
    </template>
    <template v-else>
      <p>暂无数据</p>
    </template>
    
    <p v-if="error" class="error-message">{{ error }}</p>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from "vue";
import axios from "axios";
import { useRoute } from "vue-router";

const route = useRoute();
const datalist = ref([]);
const isShow = ref(true); // 是否显示表格表头
const error = ref('');    // 错误信息
const token = localStorage.getItem("token");
const isAdmin = localStorage.getItem("isAdmin");
const userInfo = JSON.parse(localStorage.getItem("userInfo"));

// const displayedData = computed(() => {
//   return route.params.id === "1" ? datalist.value : [datalist.value];
// });

const fetchData = async (url) => {
  try {
    const res = await axios({
      method: "GET",
      url,
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    if (res.data.success) {
      if(isAdmin==='true'){
        datalist.value = res.data.data;
      }else{
        datalist.value = [res.data.data];
      }
    } else {
      isShow.value = false;
      throw new Error(res.data.message);
    }
  } catch (err) {
    error.value = err;
  }
};

onMounted(() => {
  if (isAdmin === 'true') {
    fetchData("http://localhost:5000/stus/users");
  } else {
    fetchData(`http://localhost:5000/stus/users/${userInfo.id}`);
  }
});
</script>

<style scoped>
.container {
  width: 80%;
  margin: 0 auto;
  text-align: center;
}

table {
  border-collapse: collapse;
  width: 100%;
}

td,
th {
  font-size: 18px;
  text-align: center;
  border: 1px solid #000;
}

caption {
  font-size: 20px;
  font-weight: bold;
}
button {
    padding: 10px 20px;
    background-color: yellowgreen;
    color: white;
    border: none;
    cursor: pointer;
}

button:hover {
    background-color: #0056b3;
}

img {
  width: 35px;
}

.error-message {
  color: red;
  margin-top: 10px;
}
</style>
