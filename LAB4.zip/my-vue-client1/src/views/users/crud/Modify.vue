<template>
    <div class="modify">
        <!-- 无数据，不显示 -->
        <template v-if="isShow">
            <form>
                <ul>
                    <li v-for="(item, index) in datalist" :key="item.id">
                        用户名：<input v-model="item.name" />
                        密码：<input type="password" v-model="item.pwd" />
                        年龄：<input type="number" v-model="item.age" />
                        <input v-model="item.gender" type="radio" value="男" />男
                        <input v-model="item.gender" type="radio" value="女" />女
                        地址：<input v-model="item.address" />&nbsp;
                        <button type="button" @click="modifyData(item.id, index)">修改</button>
                    </li>
                </ul>
            </form>
        </template>
        <template v-else>
            <p>暂无数据</p>
        </template>

        <p v-if="error" class="error-message">{{ error }}</p>
    </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import axios from "axios";
import { useRoute } from 'vue-router';
const route = useRoute();
const isShow = ref(true); 
const error = ref('');    
const token = localStorage.getItem("token");
const isAdmin = localStorage.getItem("isAdmin");
const userInfo = JSON.parse(localStorage.getItem("userInfo"));
let datalist = ref([]);

const fetchData = async (url) => {
        const res = await axios({
            method: "GET",
            url,
            headers: {
                "Authorization": `Bearer ${token}`
            }
        });
        if (res.data.success) {
            if(isAdmin==='true'){
                return res.data.data;
            }else{
                return [res.data.data];
            }
        } else {
            throw new Error(res.data.message);
        }
};

onMounted( async () => {
    try {
        if (isAdmin === 'true') { // 管理员
            const data = await fetchData("http://localhost:5000/stus/users");
            if (data) {
                datalist.value = data;
            }
        } else { // 普通用户
            const data = await fetchData(`http://localhost:5000/stus/users/${userInfo.id}`);
            if (data) {
                datalist.value = [data];
            }
        }
    } catch (err) {
        isShow.value = false;
        error.value = err;
    }

    
});

const modifyData = async (id, index) => {
    try {
        const res = await axios({
            method: "PUT",
            url: "http://localhost:5000/stus/users",
            headers: {
                "Authorization": `Bearer ${token}`
            },
            data: {
                id: id,
                name: datalist.value[index].name,
                pwd: datalist.value[index].pwd,
                age: datalist.value[index].age,
                gender: datalist.value[index].gender,
                address: datalist.value[index].address,
            }
        });
        if (res.data.success) {
            alert("修改成功！修改的用户请重新登录！");
            fetchData("http://localhost:5000/stus/users"); // 刷新数据列表
        } else {
            throw new Error(res.data.message);
        }
    } catch (err) {
        error.value = err;
    }
};
</script>

<style scoped>
ul {
    list-style: none;
}

.modify {
    padding-top: 50px;
    width: 100%;
    margin: 0 auto;
    text-align: center;
}

button {
    padding: 10px 20px;
    background-color: yellowgreen;
    color: white;
    border: none;
    cursor: pointer;
}

button:hover {
    background-color: #0056b3;
}
.error-message {
    color: red;
    margin-top: 10px;
}
</style>



