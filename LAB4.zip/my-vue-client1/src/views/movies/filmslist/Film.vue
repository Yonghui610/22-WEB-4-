<template>
    <div>
        <!-- {{ route.params.iddata }}
        <hr> -->

        <button @click="handleBack">返回</button>

        <h3>猜你喜欢</h3>
        <ul>
            <li @click="handleClick">电影1</li>
        </ul>
        <br>
        <div>
            <h2>{{ dataDetail.name}}</h2>
            <img :src="dataDetail.posterUrl" :width=200 alt="海报" />
            <p>剧情：{{ dataDetail.description}}</p>
            <p>评分：{{ dataDetail.popularity}}</p>
        </div>
    </div>
</template>

<script  setup>
import { ref, onMounted, watch} from 'vue'
import { useRouter, useRoute, onBeforeRouteUpdate } from 'vue-router';
import axios from "axios"
const router = useRouter();
const route = useRoute();
const dataDetail = ref({}) 
const id = route.params.iddata;
onMounted(async (e) => {
    getMovies(id);
})

const getMovies = async (id) => {
    const res = await axios({
        url: "http://localhost:5000/movies/movies/"+id,
    })
    console.log()
    if(res.data.code==200){
        dataDetail.value = res.data.data
    }
}

const handleBack = () => {
    router.push("/")
}

const handleClick = () => {
    router.push({
        name: "film",
        params: { iddata: 6640 }
    })
}
</script>

<style scoped>
button {
    padding: 10px 20px;
    background-color: yellowgreen;
    color: white;
    border: none;
    cursor: pointer;
}

button:hover {
    background-color: #0056b3;
}
</style>






