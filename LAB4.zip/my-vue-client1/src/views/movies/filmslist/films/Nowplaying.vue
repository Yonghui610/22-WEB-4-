<template>

    <table>
        <tr v-for="(row, rowIndex) in rows" :key="rowIndex">
            <td v-for="item in row" :key="item.id">
                <div>
                    <img :src="item.posterUrl" alt="" @click="handleClick(item.id)">
                    {{ item.name }}
                </div>
                <!-- 电影评分 加1 -->
                <button type="button" @click="handle(item.id)">点击加分</button>
                <p>评分：{{ item.popularity}}</p>
            </td>
        </tr>
    </table>
</template>

<script setup>

import axios from 'axios'
import { ref, onMounted, computed } from 'vue'
import { useRouter } from 'vue-router';
const router = useRouter();
const datalist = ref([])



onMounted(async () => {
        getMovies()
})

const getMovies = async () => {
    const res = await axios({
        url: "http://localhost:5000/movies/movies",
    })
    datalist.value = res.data.data.films
    datalist.value= datalist.value.sort((a, b) => b.popularity - a.popularity)
}   
const handleClick = (id) => {
    router.push({
        name: "film",
        params: { iddata: id }
    })
}


const handle = async (id) => {
    try {
        const token = localStorage.getItem('token')
        const res = await axios({
            url: `http://localhost:5000/movies/moviespopularity/${id}`,
            method: "GET",
            headers: {
                'Authorization': `Bearer ${token}`,
            }
        })
        console.log(res.data,'res.data')
        if(res.data.code === 200){
            getMovies()
        }
    } catch (err) {
        console.log("出错了！", err);
    }
}


const sortedDatalist = computed(() => {
    return [...datalist.value].sort((a, b) => b.grade - a.grade)
})
// 计算属性，根据排序后的 datalist 生成 rows
const rows = computed(() => {
    const numRows = Math.ceil(sortedDatalist.value.length / 5);
    const result = [];

    for (let i = 0; i < numRows; i++) {
        const start = i * 5;
        const end = start + 5;
        result.push(sortedDatalist.value.slice(start, end));
    }
    return result;
});




</script>

<style scoped >
table {
    border-collapse: collapse;
    width: 90%;
    border: none;
    margin: 0 auto;
}

tr {
    display: table-row;
    width: 100%;
}

td {
    font-size: 16px;
    text-align: center;
    border-bottom: 1px solid #000;
    width: 20%;
    /* 每个 td 占据 20% 的宽度，一行显示 5 个 td */
    padding: 10px;
    vertical-align: top;
    /* 使 td 内容顶部对齐 */
}

td > div {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
}

img {
    display: block;
    cursor: pointer;
    width: 100px;
    margin-bottom: 15px;
    /* 增加图片和文字之间的间距 */
}

button {
    padding: 5px;
    margin-top: 20px;
    background-color: yellowgreen;
    color: black;
    border: none;
    cursor: pointer;
}
</style>
