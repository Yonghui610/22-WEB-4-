<template>
    <div class="login">
        <form>
            电影编号：<input v-model="filmId" /><br>
            电影名称：<input v-model="name" /><br> 
            电影评分：<input v-model="popularity" /><br>
            电影描述：<textarea v-model="description" rows="4" cols="50"></textarea><br>
            <button type="button" @click="handleCreate">创建新电影</button>
        </form>

        <p v-if="error" class="error-message">{{ error }}</p>
    </div>
</template>

<script setup>
import axios from 'axios';
import { ref } from 'vue';

const filmId = ref("")
const name = ref("")
const description = ref('')
const popularity = ref('')


const error = ref('');
const handleCreate = async () => {
    // 验证表单
    if (!validateForm()) return;

    try {
        const token = localStorage.getItem("token");
        const res = await axios({
            method: "POST",
            url: "http://localhost:5000/movies/movies",
            headers: {
                "Authorization": `Bearer ${token}`
            },
            data: {
                name: name.value,
                description: description.value,
                filmId: filmId.value,
                popularity: popularity.value
            }
        });

        if (res.data.success) {
            alert(res.data.message);
        } else {
            throw new Error(res.data.message);
        }
    } catch (err) {
        error.value = err;
    }
};

// 验证表单
const validateForm = () => {
    if (!name.value || !filmId.value || !description.value) {
        alert("请确保所有字段都已填写！");
        return false;
    }
    return true;
};
</script>

<style scoped>
.login {
    padding-top: 50px;
    width: 80%;
    margin: 0 auto;
    text-align: center;
}

button {
    padding: 10px 20px;
    background-color: yellowgreen;
    color: white;
    border: none;
    cursor: pointer;
}

button:hover {
    background-color: #0056b3;
}

.error-message {
    color: red;
    margin-top: 10px;
}
</style>




