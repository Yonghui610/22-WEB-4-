<template>
    <div class="modify">
        <!-- 无数据，不显示 -->
        <template v-if="isShow"> 
            <form>
                    <div v-for="(item, index) in datalist" :key="item.id">
                        电影编号：<input v-model="item.filmId" />
                        <br>
                        电影名称：<input v-model="item.name" />
                        <br>
                        电影评分：<input type="number" v-model="item.popularity" />
                        <br>
                        电影描述：<textarea v-model="item.description" rows="10" cols="50"></textarea>
                        <br>
                        <button type="button" @click="modifyData(item.id, index)">修改</button>
                    </div>
            </form>
        </template>
        <template v-else>
            <p v-if="isAdmin==='true'">暂无数据</p>
            <p v-else>等待完善</p>
        </template>

        <p v-if="error" class="error-message">{{ error }}</p>
    </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import axios from "axios";
import { useRoute } from 'vue-router';
const route = useRoute();
const isShow = ref(true); 
const error = ref('');    
const token = localStorage.getItem("token");
const isAdmin = localStorage.getItem("isAdmin");
const userInfo = JSON.parse(localStorage.getItem("userInfo"));
let datalist = ref([]);

const fetchData = async (url) => {
        const res = await axios({
            method: "GET",
            url,
            headers: {
                "Authorization": `Bearer ${token}`
            }
        });
        if (res.data.success) {
            return res.data.data.films;
        } else {
            throw new Error(res.data.message);
        }
};

onMounted( async () => {
    try {
        if (isAdmin==='true') { // 管理员
            const data = await fetchData("http://localhost:5000/movies/movies");
            if (data) {
                isShow.value = true;
                datalist.value = data;
            }
        } else { // 普通用户
            isShow.value = false;
        }
    } catch (err) {
        isShow.value = false;
        error.value = err;
    }

    
});

const modifyData = async (id, index) => {
    try {
        const res = await axios({
            method: "PUT",
            url: "http://localhost:5000/movies/movies",
            headers: {
                "Authorization": `Bearer ${token}`
            },
            data: {
                id: id,
                filmId: datalist.value[index].filmId,
                name: datalist.value[index].name,
                description: datalist.value[index].description,
                popularity: datalist.value[index].popularity,
            }
        });
        if (res.data.success) {
            alert("修改成功！");
            fetchData("http://localhost:5000/movies/movies"); // 刷新数据列表
        } else {
            throw new Error(res.data.message);
        }
    } catch (err) {
        error.value = err;
    }
};
</script>

<style scoped>
ul {
    list-style: none;
}

.modify {
    padding-top: 50px;
    width: 100%;
    margin: 0 auto;
    text-align: center;
}

button {
    padding: 10px 20px;
    background-color: yellowgreen;
    color: white;
    border: none;
    cursor: pointer;
}

button:hover {
    background-color: #0056b3;
}
.error-message {
    color: red;
    margin-top: 10px;
}
</style>



