
<template>
    <div class="tabbar">
        <ul>
            <router-link custom to="/films" v-slot="{ isActive, navigate }">
                <li :class="isActive ? 'gljactive' : ''" @click="navigate">电影列表</li>
            </router-link>

            <router-link custom to="/cinemascenter" #="{ isActive, navigate }">
                <li :class="isActive ? 'gljactive' : ''" @click="navigate">电影管理</li>
            </router-link>

            <router-link custom to="/userscenter" #="{ isActive, navigate }">
                <li :class="isActive ? 'gljactive' : ''" @click="navigate">用户管理</li>
            </router-link>
        </ul>
    </div>
</template>


<style scoped lang="scss">
.gljactive {
    color: red ;
    transition: color 0.3s ease;
}

.tabbar {
    font-size: 16px;
    font-weight: bold;
    position: fixed;
    bottom: 5px;
    width: 100%;
    height: 50px;
    line-height: 50px;
    text-align: center;

    ul {
        display: flex;

        li {
            flex: 1;
        }
    }
}
</style>

