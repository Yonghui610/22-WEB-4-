<template>
    <ul class="header">
        <router-link custom v-for="item in items" :to="item.to" #="{ isActive, navigate }">
            <li @click="navigate">
                <span :class="isActive ? 'gljactive' : ''">{{ item.label}}</span>
            </li>
        </router-link>
    </ul>
</template>

<script setup>
import { useRoute, useRouter } from 'vue-router';

const props = defineProps({
    items: {
        type: Array,
        required: true
    }
});

</script>

<style scoped lang="scss">
.header {
    display: flex;
    height: 50px;
    line-height: 50px;
    text-align: center;

    li {
        flex: 1;

        span {
            padding: 10px 0;
        }
    }
}

.gljactive {
    color: red;
    border-bottom: 3px solid red;
}
</style>




<!-- 编程式导航，参考 -->
<!-- <template>
    <ul class="header">
        <li v-for="(item, index) in items" :key="index" @click="navigate(item.to)">
            <span :class="isActive(item.to) ? 'gljactive' : ''">{{ item.label }}</span>
        </li>
    </ul>
</template>

<script setup>
import { useRoute, useRouter } from 'vue-router';

const props = defineProps({
    items: {
        type: Array,
        required: true
    }
});

const route = useRoute();
const router = useRouter();
// console.log(router)
const isActive = (to) => {
    // router.resolve 方法来获取完整的路径
    const resolvedPath = router.resolve(to).href;
    // console.log(route.path, resolvedPath); // 打印路径进行调试
    return route.path === resolvedPath;
};

const navigate = (to) => {
    router.push(to);
};
</script>

<style scoped lang="scss">
.header {
    display: flex;
    height: 50px;
    line-height: 50px;
    text-align: center;

    li {
        flex: 1;

        span {
            padding: 10px 0;
        }
    }
}

.gljactive {
    color: red;
    border-bottom: 3px solid red;
}
</style> -->