const filmRoutes = [
  {
    path: "/",
    redirect: "/films",
  },
  {
    path: "/films",
    name: "films",
    component: () => import("@/views/movies/filmslist/Films.vue"),
    meta: {
      title: "电影首页",
    },
    children: [
      {
        path: "/films",
        redirect: "/films/nowplaying",
      },
      {
        path: "nowplaying",
        name: "nowplaying",
        component: () =>
          import("@/views/movies/filmslist/films/Nowplaying.vue"),
        meta: {
          title: "电影首页--正在热映",
        },
      },
      {
        path: "comingsoon",
        name: "comingsoon",
        component: () =>
          import("@/views/movies/filmslist/films/Comingsoon.vue"),
        meta: {
          title: "电影首页--",
        },
      },
    ],
  },
  {
    path: "/film/:iddata?", 
    name: "film",
    component: () => import("@/views/movies/filmslist/Film.vue"),
    meta: {
      title: "电影详情",
    },
  },
];

export default filmRoutes;
