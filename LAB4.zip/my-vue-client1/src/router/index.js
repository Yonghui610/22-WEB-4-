import { createRouter,createWebHistory } from 'vue-router'
import filmRoutes from "./filmRoutes";
import userManageRoutes from "./userManageRoutes";
import filmsManageRoutes from "./filmsManageRoutes";

const routes = [
  ...filmRoutes,
  ...userManageRoutes,
  ...filmsManageRoutes,

  {
    path: "/:pathMatch(.*)*",
    component: () => import("@/views/NotFound.vue"),
  },
];
const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes,
});

// 前置路由守卫、前置拦截（钩子）
router.beforeEach( async (to, from) => {
  const { title, requiredAuth } = to.meta;

  // 只有在路由发生变化时才设置 document.title
  if (to.fullPath !== from.fullPath && title) {
    document.title = title;
  }

  // 检查是否需要认证
  if (requiredAuth) {
    let isAuthenticated = localStorage.getItem("token");
    if (!isAuthenticated) {
      if (to.name === "userscenter") {
        return { name: "usermanagelogin" };
      } else if (to.path.includes("/cinemascenter")) {
        return { name: "filmsmanagelogin" };
      }
    }
  }
  // 正常放行
  return true;
})
export default router;

