const userManageRoutes = [
  {
    path: "/filmsmanagelogin",
    name: "filmsmanagelogin",
    component: () => import("@/views/movies/filmsmanage/FilmManageLogin.vue"),
    meta: {
      title: "电影管理中心--登录/注册",
    },
  },

  {
    path: "/cinemascenter",
    name: "cinemascenter",
    component: () => import("@/views/movies/filmsmanage/CinemasCenter.vue"),
    meta: {
      title: "电影中心",
      requiredAuth: true,
    },
    beforeEnter: (to, from) => {
      let isAuthenticated = localStorage.getItem("token");
      if (!isAuthenticated) return { name: "filmsmanagelogin" };
      return true;
    },
    children: [
      {
        path: "/cinemascenter",
        redirect: "/cinemascenter/filmselect",
      },
      {
        path: "filmselect",
        name: "filmselect",
        component: () => import("@/views/movies/filmsmanage/crud/Select.vue"),
        meta: {
          title: "电影中心--电影查询",
          requiredAuth: true,
        },
      },
      {
        path: "filmcreate",
        name: "filmcreate",
        component: () => import("@/views/movies/filmsmanage/crud/Create.vue"),
        meta: {
          title: "电影中心--电影创建",
          requiredAuth: true,
        },
      },
      {
        path: "filmdelete",
        name: "filmdelete",
        component: () => import("@/views/movies/filmsmanage/crud/Delete.vue"),
        meta: {
          title: "电影中心--电影删除",
          requiredAuth: true,
        },
      },
      {
        path: "filmmodify",
        name: "filmmodify",
        component: () => import("@/views/movies/filmsmanage/crud/Modify.vue"),
        meta: {
          title: "电影中心--电影修改",
          requiredAuth: true,
        },
      },
    ],
  },
];

export default userManageRoutes;
