import{_ as o,o as n,c}from"./index-c03b1af7.js";const e={};function r(s,t){return n(),c("div",null," comingsoon ")}const a=o(e,[["render",r]]);export{a as default};
