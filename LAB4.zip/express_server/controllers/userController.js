const userService = require("../services/userService");

// 引入
const jwt = require("jsonwebtoken");


// 登录
exports.login = async (req, res, next) => {
  try {
    const { name, pwd } = req.body;
    const user = await userService.getUserByName(name);
    if (!user) {
      return res.send({
        code: 1001,
        success: false,
        message: "账号不存在",
      });
    }
    if (user.pwd !== pwd) {
      return res.send({
        code: 1002,
        success: false,
        message: "密码错误",
      });
    }
    // 登录成功，生成token
    const secretKey = "chaojianquanmima";
    const token = jwt.sign({ user }, secretKey, { expiresIn: "1h" });
    // 区分管理员或其他用户
    if (user.name === "20222830") {
      return res.send({
        code: 200,
        success: true,
        message: "登录成功",
        data: {
          token,
          data: user,
          nickname: "管理员",
        },
      });
    } else {
      return res.send({
        code: 200,
        success: true,
        message: "登录成功",
        data: {
          token,
          data: user,
          nickname: "普通用户",
        },
      });
    }
  } catch (err) {
    next(err);
  }
};

// 注册
exports.register = async (req, res, next) => {
  console.log(req.body, '注册');
  try {
    const { name, pwd, age, gender, address } = req.body;
    const user = await userService.getUserByName(name);
    if (user) {
      return res.send({
        code: 1004,
        success: false,
        message: "账号已存在，请重新输入",
      });
    }
    const newUser = {
      name,
      pwd,
      age,
      gender,
      address,
      imgUrl: "http://localhost:5000/images/peoples/员工.png",
    };
    await userService.createUser(newUser);
    // 登录成功，生成token
    const secretKey = "chaojianquanmima";
    const token = jwt.sign({ user }, secretKey, { expiresIn: "1h" });
    res.send({
      code: 200,
      success: true,
      message: "注册成功",
      data: {
        token,
        data: newUser,
        nickname: "普通用户",
      },
    });
  } catch (err) {
    next(err);
  }
};


// 获取所有用户
exports.getUsers = async (req, res, next) => {
  try {
    const users = await userService.getUsers();
    if (!users) {
      // return res.status(403).send({  // 增加前端判断难度 axios中catch分支处理
      return res.send({
        //  axios中then分支处理
        code: 404,
        success: false,
        message: "未找到学生信息",
      });
    } else {
      res.send({
        code: 200,
        success: true,
        message: "查询学生信息成功",
        data: users,
      });
    }
  } catch (err) {
    next(err);
  }
};



// 根据 ID 获取单个用户
exports.getUserById = async (req, res, next) => {
  try {
    const user = await userService.getUserById(req.params.id);
    if (!user) {
      return res.send({
        code: 1003,
        success: false,
        message: "获取用户数据失败,请确认查询id！",
      });
    } else {
      res.send({
        code: 200,
        success: true,
        message: "查询学生信息成功",
        data: user,
      });
    }
  } catch (err) {
    next(err);
  }
};


// 创建新用户
exports.createUser = async (req, res, next) => {
  try {
    const newUser = req.body;
    console.log(newUser);

    // 简单的判断：不允许账号重复
    const createUserResult = await userService.getUserByName(newUser.name);
    if (createUserResult) {
      return res.send({
        code: 1004,
        success: false,
        message: "账号已存在，请重新输入",
      });
    } else {
      newUser.imgUrl = "http://localhost:5000/images/peoples/员工.png";
      const userId = await userService.createUser(newUser);
      res.send({
        code: 200,
        success: true,
        message: "添加学生信息成功",
        data: {
          data: userId,
          nickname: "普通注册用户",
        },
      });
    }
  } catch (err) {
    next(err);
  }
};

// 删除用户
exports.deleteUser = async (req, res, next) => {
  try {
    const deleteUserId = req.params.id;
    const deleteUserResult = await userService.getUserById(deleteUserId);

    if (!deleteUserResult) {
      return res.send({
        code: 1006,
        success: false,
        message: "学生id不存在,请确认删除id！",
      });
    } else {
      await userService.deleteUser(deleteUserId);
      res.send({
        code: 200,
        success: true,
        message: "删除学生信息成功",
      });
    }
  } catch (err) {
    next(err);
  }
};




// 更新用户
exports.updateUser = async (req, res, next) => {
  try {
    const updatedUser = req.body;

    // 通过id查找是否存在这个用户
    const updateUserResult = await userService.getUserById(updatedUser.id);

    if (!updateUserResult) {
      // updateUserResult是null
      return res.send({
        code: 1005,
        success: false,
        message: "学生id不存在,请确认修改id！",
      });
    } else {
      updatedUser.imgUrl = updateUserResult.imgUrl;

      // 更新用户
      await userService.updateUser(updatedUser);
      res.send({
        code: 200,
        success: true,
        message: "更新学生信息成功",
      });
    }
  } catch (err) {
    next(err);
  }
};



