
const { expressjwt: jwt } = require("express-jwt");
const secretKey = "chaojianquanmima";

// 使用 express-jwt 创建中间件
const authenticationToken = jwt({
  secret: secretKey,
  algorithms: ["HS256"], // 指定算法
});



// 自定义错误处理中间件
function handleJwtError(err, req, res, next) {
  if (err.name === 'UnauthorizedError') {
    // 验证失败
    res
      .status(401)
      .send({
        code: 401,
        success: false,
        message: "Token is not valid",
      });
  } else {
    // 其他错误
    next(err);
  }
}

// 导出中间件
module.exports = authenticationToken;
module.exports.handleJwtError = handleJwtError;
