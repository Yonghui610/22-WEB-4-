import { defineConfig } from 'vite';
import legacy from '@vitejs/plugin-legacy';
import path from 'path';

export default defineConfig({
    plugins: [legacy()],
    resolve: {
        alias: {
            '@': path.resolve(__dirname, './src'),
        },
    },
});
