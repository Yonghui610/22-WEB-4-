import "./style/index.css";
import { login } from "@/login-out/login.js";
import { logout } from "@/login-out/logout.js";
import { loadData } from "@/crud/loadData.js";
import { postData } from "@/crud/postData.js";
import { deleteData } from "@/crud/deleteData.js";
import { putData } from "@/crud/putData.js";

const root = document.getElementById("app");

if (localStorage.getItem("token")) {
  const nickname = localStorage.getItem("nickname");

  if (nickname === "管理员") {
    root.innerHTML = `
      <h1>欢迎 ${nickname} 回来！</h1>
      <hr>
      <button id="load-btn">加载数据</button>
      <button id="post-btn">添加数据</button>
      <button id="logout-btn">注销</button>
      <hr>
      <div id="data"></div>
    `;
  } else {
    const userData = JSON.parse(localStorage.getItem("userData"));
    const { id, name, age, gender, address, imgUrl } = userData;
    root.innerHTML = `
      <h1>欢迎 ${nickname} 回来！</h1>
      <hr>
      <ul>
        <li>${id}</li>
        <li>${name}</li>
        <li>${age}</li>
        <li>${gender}</li>
        <li>${address}</li>
        <li><img src="${imgUrl}" alt="头像"></li>
      </ul>
      <button id="put-btn">修改</button>
      <button id="logout-btn">注销</button>
      <hr>
    `;
    document.getElementById("put-btn").onclick = () => putData(id);
  }

  document.getElementById("load-btn")?.addEventListener("click", loadData);
  document.getElementById("post-btn")?.addEventListener("click", postData);
  document.getElementById("logout-btn")?.addEventListener("click", logout);
} else {
  login(root);
}
