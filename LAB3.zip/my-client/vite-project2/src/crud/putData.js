import axios from "axios";
import { loadData } from "@/crud/loadData.js";
export async function putData(id) {
    const token = localStorage.getItem("token");

    try {
        const res = await axios.put(
            "http://localhost:5000/users",
            {
                id,
                name: "猪哼哼",
                pwd: "123456",
                age: 38,
                gender: "男",
                address: "猪圈",
            },
            {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            }
        );
        if (res.data.success) {
            console.log("修改成功！");
            loadData(); // 修改后重新加载数据
        }
    } catch (err) {
        console.error("修改失败：", err);
    }
}
