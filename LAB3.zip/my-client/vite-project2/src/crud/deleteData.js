import axios from "axios";
import { loadData } from "@/crud/loadData.js";

export async function deleteData(id) {
    const token = localStorage.getItem("token");

    try {
        const res = await axios.delete(`http://localhost:5000/users/${id}`, {
            headers: {
                Authorization: `Bearer ${token}`,
            },
        });

        if (res.data.success) {
            console.log("删除成功！");
            loadData(); // 删除后重新加载数据
        }
    } catch (err) {
        console.error("删除失败：", err);
    }
}
