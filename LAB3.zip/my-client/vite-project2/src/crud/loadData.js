import axios from "axios";
import { deleteData } from "@/crud/deleteData.js";
import { putData } from "@/crud/putData.js";
export async function loadData() {
  const token = localStorage.getItem("token");
  const dataDiv = document.getElementById("data");
  dataDiv.innerHTML = ""; // 清空已有内容
  try {
    const res = await axios.get("http://localhost:5000/users", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    const stuData = res.data.data;
    if (res.data.success) {
      const table = document.createElement("table");
      table.innerHTML = `
        <caption>学生列表</caption>
        <thead>
          <tr>
            <th>学号</th>
            <th>姓名</th>
            <th>年龄</th>
            <th>性别</th>
            <th>地址</th>
            <th>头像</th>
            <th>操作</th>
          </tr>
        </thead>
        <tbody>
          ${stuData
          .map(
            (stu) => `
            <tr data-id="${stu.id}">
              <td>${stu.id}</td>
              <td>${stu.name}</td>
              <td>${stu.age}</td>
              <td>${stu.gender}</td>
              <td>${stu.address}</td>
              <td><img src="${stu.imgUrl}" alt="头像"></td>
              <td>
                <button class="put-btn">修改</button>
                <button class="delete-btn">删除</button>
              </td>
            </tr>`
          )
          .join("")}
        </tbody>
      `;
      dataDiv.appendChild(table);

      // 使用事件委托绑定修改和删除按钮
      table.addEventListener("click", (event) => {
        const target = event.target;
        const row = target.closest("tr"); // 获取按钮所在行
        const id = row?.dataset.id; // 获取学生ID

        if (target.classList.contains("put-btn")) {
          putData(id); // 调用修改函数
        } else if (target.classList.contains("delete-btn")) {
          deleteData(id); // 调用删除函数
        }
      });
    }
  } catch (err) {
    console.error("加载数据失败：", err);
  }
}
