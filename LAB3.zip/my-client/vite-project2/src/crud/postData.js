import axios from "axios";
export async function postData() {
    const token = localStorage.getItem("token");
    try {
        const res = await axios.post(
            "http://localhost:5000/users",
            {
                name: "白骨精",
                pwd: "111111",
                age: 16,
                gender: "女",
                address: "白骨洞",
            },
            {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            }
        );
        if (res.data.success) {
            console.log("添加成功！");
            location.reload();
        }
    } catch (err) {
        console.error("添加失败：", err);
    }
}
