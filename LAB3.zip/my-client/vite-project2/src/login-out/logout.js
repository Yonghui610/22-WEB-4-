export function logout() {
    localStorage.clear();
    location.reload(); // 刷新页面回到登录界面
}
