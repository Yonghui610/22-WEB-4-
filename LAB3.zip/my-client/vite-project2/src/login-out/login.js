import axios from "axios";

export function login(root) {
    root.innerHTML = `
    <h1>请登录以后再做操作</h1>
    <h2 id="info"></h2>
    <form>
      <div>
        <input id="username" type="text" placeholder="用户名" />
      </div>
      <div>
        <input id="password" type="password" placeholder="密码" />
      </div>
      <div>
        <button id="login-btn" type="button">登录</button>
      </div>
    </form>
  `;

    document.getElementById("login-btn").onclick = async () => {
        const name = document.getElementById("username").value.trim();
        const pwd = document.getElementById("password").value.trim();

        try {
            const res = await axios.post("http://localhost:5000/login", { name, pwd });
            const { token, nickname, data } = res.data.data;

            localStorage.setItem("token", token);
            localStorage.setItem("nickname", nickname);
            localStorage.setItem("userData", JSON.stringify(data));

            location.reload(); // 刷新页面加载主界面
        } catch (err) {
            document.getElementById("info").innerText = "登录失败，请重试！";
        }
    };
}
