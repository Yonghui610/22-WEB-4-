import axios from "axios";

const instance = axios.create({
    baseURL: "http://localhost:5000",
    timeout: 10000,
});

// 请求拦截器
instance.interceptors.request.use(
    async (config) => {
        console.log("请求拦截器执行了");
        let token = localStorage.getItem("token");
        console.log("Token:", token); // 检查 token
        if (token) {
            config.headers["Authorization"] = `Bearer ${token}`;
        }
        console.log("请求配置：", config); // 检查完整配置
        return config;
    },
    (err) => {
        console.error("请求拦截器错误：", err);
        return Promise.reject(err);
    }

);

// 响应拦截器
instance.interceptors.response.use(
    (res) => {
        console.log("响应拦截器执行了");
        if (res.data.code !== 200) {
            const errorMessage = res.data.message || "未知错误";
            handleErrorMessage(errorMessage);
            return Promise.reject(res.data);
        }
        return res.data;
    },
    (error) => {
        const errorMessage = error.response?.data.message || "未知错误";
        handleErrorMessage(errorMessage);
        return Promise.reject(error);
    }
);

function handleErrorMessage(message) {
    console.error(message);
}

export default instance;