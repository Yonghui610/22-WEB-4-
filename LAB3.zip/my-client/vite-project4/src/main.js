import "./style/index.css"; // 引入样式
import { login } from "@/login-out/login";


// 渲染登录界面并挂载到 #app
document.querySelector("#app").innerHTML = `
    <div id="root">
        <h1>请登录以后再做操作</h1>
        <h2 id="info"></h2>
        <form>
            <div>
                <input id="username" type="text" placeholder="用户名" />
            </div>
            <div>
                <input id="password" type="password" placeholder="密码" />
            </div>
            <div>
                <button id="login-btn" type="button">登录</button>
            </div>
        </form>
    </div>
`;

// 挂载登录功能到按钮
const loginBtn = document.getElementById("login-btn");
login(loginBtn);
