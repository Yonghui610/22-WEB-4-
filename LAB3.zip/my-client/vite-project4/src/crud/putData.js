import instance from "@/api/aixos-instance.js";
export async function putData(id) {
    try {
        console.log(`正在修改用户ID为: ${id}`); // 调试信息
        const res = await instance.put(`/users`, {
            id, // 将 ID 放入请求体中
            name: "猪啸啸",
            pwd: "123456",
            age: 38,
            gender: "男",
            address: "猪圈",
        });
        console.log("服务器响应：", res);
        if (res.success) {
            console.log("更新成功！");
            await loadData();
        }
    } catch (err) {
        console.error("更新数据失败", err);
        throw err;
    }
}
