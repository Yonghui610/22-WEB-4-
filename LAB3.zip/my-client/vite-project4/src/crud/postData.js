import instance from "@/api/aixos-instance.js";

export async function postData() {
    try {
        const res = await instance.post("/users", {
            name: "白骨精",
            pwd: "111111",
            age: 16,
            gender: "女",
            address: "白骨洞",
        });
        console.log(res);
        if (res.success) {
            console.log("添加成功！");
            await loadData();
        }
    } catch (err) {
        console.error("添加数据失败", err);
        throw err;
    }
}