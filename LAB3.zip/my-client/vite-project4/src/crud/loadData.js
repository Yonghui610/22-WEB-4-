import instance from "@/api/aixos-instance.js";
export async function loadData() {
  try {
    const res = await instance.get("/users", {
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`, // 手动添加头部
      },
    });
    console.log(res);
    if (res.success) {
      const dataDiv = document.getElementById("data");
      const table = document.createElement("table");
      table.insertAdjacentHTML(
        "beforeend",
        `<caption>学生列表</caption>
                <thead>
                    <tr>
                      <th>学号</th>
                      <th>姓名</th>
                      <th>年龄</th>
                      <th>性别</th>
                      <th>地址</th>
                      <th>头像</th>
                      <th>操作</th>
                    </tr>
                </thead>
                <tbody></tbody>`
      );
      dataDiv.appendChild(table);
      const tbody = table.querySelector("tbody");

      res.data.forEach((stu) => {
        tbody.insertAdjacentHTML(
          "beforeend",
          `<tr>
                        <td>${stu.id}</td>
                        <td>${stu.name}</td>
                        <td>${stu.age}</td>
                        <td>${stu.gender}</td>
                        <td>${stu.address}</td>
                        <td><img src="${stu.imgUrl}"  alt="头像" ></td>
                        <td>
                            <button onclick="putData(${stu.id})">修改</button>
                            <button onclick="deleteData(${stu.id})">删除</button>
                        </td>
                    </tr>`
        );
      });
    }
  } catch (err) {
    console.error("加载数据失败", err);
    throw err;
  }
}