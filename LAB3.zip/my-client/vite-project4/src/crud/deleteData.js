import instance from "@/api/aixos-instance.js";

export async function deleteData(id) {
    try {
        const res = await instance.delete(`/users/${id}`);
        console.log(res);
        if (res.success) {
            await loadData(); // 重新加载数据
        }
    } catch (err) {
        console.error("删除数据失败", err);
        throw err;
    }
}