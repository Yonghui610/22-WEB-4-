import instance from "@/api/aixos-instance.js";
import { loadData } from "@/crud/loadData";
import { postData } from "@/crud/postData";
import { putData } from "@/crud/putData";
import { deleteData } from "@/crud/deleteData";
import { logout } from "./logout";

// 添加到window对象上，方便在html中调用
window.loadData = loadData;
window.postData = postData;
window.putData = putData;
window.deleteData = deleteData;
window.logout = logout;

export const login = (element) => {
  const loginBtn = element;
  const root = document.getElementById("root");

  // 检查本地存储中的 token 和 nickname
  const token = localStorage.getItem("token");
  const nickname = localStorage.getItem("nickname");

  // 如果用户已登录
  if (token) {
    renderUserInterface(root, nickname);
  } else {
    // 如果用户未登录，绑定登录事件
    loginBtn.onclick = async () => {
      const name = document.getElementById("username").value.trim();
      const pwd = document.getElementById("password").value.trim();

      try {
        const res = await instance.post("/login", { name, pwd });
        const { token, nickname } = res.data;

        // 存储 token 和 nickname
        localStorage.setItem("token", token);
        localStorage.setItem("nickname", nickname);

        renderUserInterface(root, nickname, res.data.data);
      } catch (err) {
        console.error("登录失败", err);
        document.getElementById("info").innerText = "登录失败";
      }
    };
  }
};

// 渲染用户界面
function renderUserInterface(root, nickname, userData = null) {
  if (nickname === "管理员") {
    root.innerHTML = `
      <h1>欢迎 ${nickname} 回来！</h1>
      <hr>
      <button onclick="loadData()">加载数据</button>
      <button onclick="postData()">添加数据</button>
      <button onclick="logout()">注销</button>
      <hr>
      <div id="data"></div>
    `;
  } else if (userData) {
    const { id, name, age, gender, address, imgUrl } = userData;
    root.innerHTML = `
      <h1>欢迎 ${nickname} 回来！</h1>
      <hr>
      <ul>
          <li>${id}</li>
          <li>${name}</li>
          <li>${age}</li>
          <li>${gender}</li>
          <li>${address}</li>
          <li><img src="${imgUrl}" alt="头像" /></li>
      </ul>
      <button onclick="putData(${id})">修改</button>
      <button onclick="logout()">注销</button>
      <hr>
    `;
  }
}
