const express = require("express");
const router = express.Router();

// 使用user路由
router.use( require('./users'));


// 使用其他...

module.exports = router;
