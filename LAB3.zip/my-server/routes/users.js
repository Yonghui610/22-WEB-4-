const express = require("express");
const router = express.Router();

const authenticationToken = require("../middleware/authenticationToken");


// 模块化
// 分清route 、controllers、services、models各自的功能

// 引入userController
const userController = require("../controllers/userController");


// 确定不同的请求方式路由，指定路由处理函数--userController



// 登录    userController.login回调userController.js中的login方法
router.post("/login", userController.login);


// 使用中间件保护其他路由  登录路由不需要验证 token
router.use(authenticationToken);

// 添加错误处理中间件
router.use(authenticationToken.handleJwtError);


// 获取所有用户
router.get("/users", userController.getUsers);

// 根据 ID 获取单个用户
router.get("/users/:id", userController.getUserById);

// 创建新用户
router.post("/users", userController.createUser);

// 删除用户
router.delete("/users/:id", userController.deleteUser);

// 更新用户
router.put("/users", userController.updateUser);



module.exports = router;
